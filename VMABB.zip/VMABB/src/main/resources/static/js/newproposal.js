document.addEventListener("DOMContentLoaded", function() {
	// Get the form and premium display elements
	const proposalForm = document.getElementById("proposalForm");
	const premiumDisplay = document.getElementById("premiumDisplay");

	// Add a submit event listener to the form
	proposalForm.addEventListener("submit", async function(event) {
		event.preventDefault(); // Prevent the default form submission

		try {
			// Collect user input from the form
			const formData = new FormData(proposalForm);

			// Send user input to the backend for premium calculation
			const response = await fetch("/calculate-premium", {
				method: "POST",
				body: formData,
			});

			if (!response.ok) {
				throw new Error(`HTTP error! Status: ${response.status}`);
			}

			const data = await response.json();

			if (data.premium !== undefined) {
				// Display the calculated premium
				premiumDisplay.textContent = `Initial Premium: $${data.premium.toFixed(2)}`;

				// Additional functionalities:
				// 1. Payment Tenure Adjustment
				const PaymentTenure = parseInt(document.getElementById("PaymentTenure").value);
				data.premium += paymentTenureAdjustment(PaymentTenure);

				// 2. Premium Reduction Based on Payment Mode
				const paymentMode = document.getElementById("paymentMode").value;
				data.premium -= paymentModeAdjustment(paymentMode, data.premium);

				// 3. Display Updated Premium
				premiumDisplay.textContent += `\nUpdated Premium: $${data.premium.toFixed(2)}`;
			} else {
				// Handle errors or invalid responses from the backend
				premiumDisplay.textContent = "Error calculating premium.";
			}
		} catch (error) {
			console.error("Error:", error);
			premiumDisplay.textContent = "Error calculating premium.";
		}
	});

	// Function to calculate Payment Tenure Adjustment
	function paymentTenureAdjustment(PaymentTenure) {
		// Customize this adjustment logic based on your requirements
		return PaymentTenure * 5; // Example adjustment
	}

	// Function to calculate Premium Reduction Based on Payment Mode
	function paymentModeAdjustment(paymentMode, premium) {
		if (paymentMode === "half-yearly") {
			return premium * 0.1; // 10% reduction for half-yearly
		} else if (paymentMode === "annual") {
			return premium * 0.15; // 15% reduction for annual
		} else {
			return 0; // No reduction for monthly
		}
	}

	// Add an event listener for the Calculate Premium button
	document.getElementById("calculatePremiumButton").addEventListener("click", function(event) {
		event.preventDefault();

		// This is where you should add the code to generate the premium based on the user's inputs
		// For example, you can call an API or use a JavaScript function to calculate it

		// Once you have the premium value, you can display it in the premiumDisplay element
		// For example:
		// premiumDisplay.textContent = "Premium: $500"; // Replace with the actual premium value
	});

	document.addEventListener("DOMContentLoaded", function() {
		// ... (Previous code for premium calculation)

		// Add an event listener for the Final Submit button
		document.getElementById("finalSubmitButton").addEventListener("click", function(event) {
			event.preventDefault();

			// Gather user input from the form fields
			const proposalData = {
				age: parseInt(document.getElementById("age").value),
				isSmoker: document.getElementById("isSmoker").checked,
				lifeCoverAmount: parseFloat(document.getElementById("lifeCoverAmount").value),
				annualIncome: parseFloat(document.getElementById("annualIncome").value),
				accidentDeathBenefit: document.getElementById("accidentDeathBenefit").checked,
				accidentDeathCoverage: parseFloat(document.getElementById("accidentDeathCoverage").value),
				comprehensiveCare: document.getElementById("comprehensiveCare").checked,
				comprehensiveCareCoverage: parseFloat(document.getElementById("comprehensiveCareCoverage").value),
				PaymentTenure: parseInt(document.getElementById("PaymentTenure").value),
				city: document.getElementById("city").value,
				qualification: document.getElementById("qualification").value,
				occupation: document.getElementById("occupation").value,
				paymentMode: document.getElementById("paymentMode").value,
				premium: parseFloat(data.premium.toFixed(2)) // Use the calculated premium from earlier
			};

			// Send the proposal data to your server for processing and database storage
			fetch("/proposals/create", {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
				},
				body: JSON.stringify(proposalData),
			})
				.then((response) => response.json())
				.then((data) => {
					// Handle the response (e.g., display a success message)
					alert("Proposal submitted successfully with Proposal ID: " + data.proposalId);
				})
				.catch((error) => {
					// Handle errors
					console.error("Error submitting proposal:", error);
				});
		});
	});
});