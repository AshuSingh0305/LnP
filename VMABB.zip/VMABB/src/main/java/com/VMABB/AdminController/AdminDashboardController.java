//anages admin dashboard interactions

package com.VMABB.AdminController;

public class AdminDashboardController {

}
