//Data Transfer Object for rider-related data

package com.VMABB.dto;

public class RiderDTO {

}
