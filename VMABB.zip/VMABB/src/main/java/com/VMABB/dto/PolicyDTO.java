//Data Transfer Object for policy-related data

package com.VMABB.dto;

public class PolicyDTO {

}
