//Data Transfer Object for payment-related data

package com.VMABB.dto;

public class PaymentDTO {

}
