//Data Transfer Object for proposal-related data

package com.VMABB.dto;

public class ProposalDTO {

}
