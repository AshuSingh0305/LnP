//Handles admin-related actions

package com.VMABB.admin;

public class AdminController {

}
