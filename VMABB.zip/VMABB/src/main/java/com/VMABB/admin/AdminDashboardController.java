//anages admin dashboard interactions

package com.VMABB.admin;

public class AdminDashboardController {

}
