//Data Transfer Object for admin dashboard data

package com.VMABB.admin.dto;

public class AdminDashboardDTO {

}
