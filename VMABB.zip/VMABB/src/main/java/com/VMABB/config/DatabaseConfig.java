//Configuration for database connection (Hibernate, MySQL)

package com.VMABB.config;

public class DatabaseConfig {

}
