// Configuration for Spring Web

package com.VMABB.config;

public class WebConfig {

}
