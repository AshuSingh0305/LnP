//Handles payment data
package com.VMABB.repository;

public class PaymentRepository {

}
