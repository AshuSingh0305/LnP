//Manages policy data

package com.VMABB.repository;

public class PolicyRepository {

}
