///Manages rider data

package com.VMABB.repository;

public class RiderRepository {

}
