//Represents payment details

package com.VMABB.model;

public class Payment {

}
