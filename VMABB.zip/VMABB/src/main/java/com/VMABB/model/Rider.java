// Represents insurance riders

package com.VMABB.model;

public class Rider {

}
