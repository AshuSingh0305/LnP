//Provides services for admin tasks (approval, rejection).

package com.VMABB.service;

public class AdminService {

}
