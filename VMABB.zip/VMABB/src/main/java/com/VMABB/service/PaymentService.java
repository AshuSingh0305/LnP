//Handles payments and premium calculations

package com.VMABB.service;

public class PaymentService {

}
