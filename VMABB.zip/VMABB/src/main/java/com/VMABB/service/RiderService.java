// Manages insurance riders

package com.VMABB.service;

public class RiderService {

}
