//Utility for premium calculations

package com.VMABB.util;

public class PremiumCalculator {

}
