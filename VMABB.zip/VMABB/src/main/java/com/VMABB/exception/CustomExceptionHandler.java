//Handles custom exceptions and provides error responses

package com.VMABB.exception;

public class CustomExceptionHandler {

}
